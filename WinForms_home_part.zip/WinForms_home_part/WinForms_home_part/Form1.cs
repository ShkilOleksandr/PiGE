﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;


namespace WinForms_home_part
{
    public partial class Form1 : Form
    {
        private string currentFilePath;
        public Form1()
        {
            InitializeComponent();
            
        }
        private void Form1_Load(object sender, EventArgs e)
        {

            toolStrip3.Dock = DockStyle.Right;
            resizableImageControl1 = new ResizableImageControl();
            panel1.Controls.Add(resizableImageControl1);
            this.Controls.Add(menuStrip1);
            this.Controls.Add(toolStrip2);
            this.Controls.Add(toolStrip3);
            this.Controls.Add(panel2);
            panel1.Invalidate();
            panel1.MouseWheel += resizableImageControl1.ResizableImageControl_MouseWheel;
            panel1.AutoScroll = true;
            resizableImageControl1.MouseCoords = toolStripLabel1;
            resizableImageControl1.SelectionCoords = toolStripLabel3;
            resizableImageControl1.MouseMove += new MouseEventHandler(Form_MouseMove);
            resizableImageControl1.MouseMove += Form_MouseMove;
            toolStripLabel2.Text = $"800 px, 600 px";
            
        }

        private void editToolStripMenuItem1_Click(object sender, EventArgs e)
        {

        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog
            {
                Filter = "Image Files (*.jpg;*.jpeg;*.png;*.bmp)|*.jpg;*.jpeg;*.png;*.bmp|All Files (*.*)|*.*"
            };

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    
                    Bitmap image = new Bitmap(openFileDialog.FileName);

                 
                    if (!panel1.Controls.Contains(resizableImageControl1))
                    {
                        panel1.Controls.Add(resizableImageControl1);
                    }

                    panel1.Size = image.Size;

                  
                    resizableImageControl1.LoadImage(image);

                    toolStripLabel2.Text = $"{image.Width} px, {image.Height} px";

    
                    resizableImageControl1.Size = image.Size;
                    resizableImageControl1.BringToFront();
                    UpdateFileBox(openFileDialog.FileName);
                    toolStrip3.Invalidate();
        
                    panel1.AutoScroll = true;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error loading image: " + ex.Message);
                }
            }
        }

     
        private void saveAsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using (SaveFileDialog saveFileDialog = new SaveFileDialog())
            {
                saveFileDialog.Filter = "PNG Image|*.png|JPEG Image|*.jpg|Bitmap Image|*.bmp";
                saveFileDialog.Title = "Save Art";
                saveFileDialog.FilterIndex = 1;
                saveFileDialog.RestoreDirectory = true;

                if (!string.IsNullOrEmpty(currentFilePath))
                {
                    saveFileDialog.FileName = currentFilePath;
                }

                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    currentFilePath = saveFileDialog.FileName;
                    SaveImage(currentFilePath, saveFileDialog.FilterIndex);
                }
            }
        }
        private void SaveImage(string filePath, int filterIndex)
        {
            if (resizableImageControl1.Canvas == null || resizableImageControl1.Canvas.Bitmap == null) return;
            switch (filterIndex)
            {
                case 1:
                    resizableImageControl1.Canvas.Bitmap.Save(filePath, System.Drawing.Imaging.ImageFormat.Png);
                    break;
                case 2:
                    resizableImageControl1.Canvas.Bitmap.Save(filePath, System.Drawing.Imaging.ImageFormat.Jpeg);
                    break;
                case 3:
                    resizableImageControl1.Canvas.Bitmap.Save(filePath, System.Drawing.Imaging.ImageFormat.Bmp);
                    break;
            }
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(currentFilePath))
            {
                SaveImage(currentFilePath, GetFilterIndexForFilePath(currentFilePath));
            }
            else
            {
                saveAsToolStripMenuItem_Click(sender, e);
            }   
        }
        private int GetFilterIndexForFilePath(string filePath)
        {
            var extension = Path.GetExtension(filePath).ToLower();
            switch (extension)
            {
                case ".png":
                    return 1;
                case ".jpg":
                case ".jpeg":
                    return 2;
                case ".bmp":
                    return 3;
                default:
                    return 1;
            }
        }
        private void Form_MouseMove(object sender, MouseEventArgs e)
        {
          
            toolStripLabel1.Text = $"Mouse Position: {e.X}, {e.Y} px      ";
            toolStripLabel1.Invalidate();
        }

        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using (WindowsFormsApp2.FormNewImage formNewImage = new WindowsFormsApp2.FormNewImage())
            {
                formNewImage.StartPosition = FormStartPosition.CenterParent;
                if (formNewImage.ShowDialog() == DialogResult.OK)
                {
                    int width = (int)formNewImage.ImageWidth;
                    int height = (int)formNewImage.ImageHeight;
                    Color backgroundColor = formNewImage.SelectedColor;

                    if (resizableImageControl1.Canvas != null)
                    {
                        resizableImageControl1.Canvas.Dispose();
                    }

                   
                    resizableImageControl1.Canvas = new DirectBitmap(width, height);
                    using (Graphics g = Graphics.FromImage(resizableImageControl1.Canvas.Bitmap))
                    {
                        g.Clear(backgroundColor);
                    }

                    resizableImageControl1.Size = new Size(width, height);
                    resizableImageControl1.Invalidate();
                    toolStripLabel2.Text = $"{width} px, {height} px";
                }
            }
        }

        private void invertColorsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            resizableImageControl1.Canvas.InvertColors();
            resizableImageControl1.Invalidate();
        }

        private void UpdateFileBox(string newFile)
        {
            string current = Path.GetFileName(newFile);
            string temp;
            foreach (ToolStripItem item in toolStrip3.Items)
            {
  
                    temp = current;
                    current = item.Text;
                    item.Text = temp;
                
            }
        }
        private void selectAllToolStripMenuItem_Click(object sender, EventArgs e)
        {
       
        }

        private void toolStripButton9_Click(object sender, EventArgs e)
        {
            resizableImageControl1.PenColor = Color.Black;
        }

        private void toolStripButton8_Click(object sender, EventArgs e)
        {
            resizableImageControl1.PenColor = Color.Gold;
        }

        private void toolStripButton7_Click(object sender, EventArgs e)
        {
            resizableImageControl1.PenColor = Color.Orange;
        }

        private void toolStripButton6_Click(object sender, EventArgs e)
        {
            resizableImageControl1.PenColor = Color.Red;
        }

        private void toolStripButton5_Click(object sender, EventArgs e)
        {
            resizableImageControl1.PenColor = Color.Purple;
        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            resizableImageControl1.PenColor = Color.Magenta;
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            resizableImageControl1.PenColor = Color.Indigo;
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            resizableImageControl1.PenColor = Color.Blue;
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            resizableImageControl1.PenColor = Color.DodgerBlue;
        }

        private void zoomInToolStripMenuItem_Click(object sender, EventArgs e)
        {
            resizableImageControl1.zoomFactor *= 1.1f;
            resizableImageControl1.Invalidate();
        }

        private void zoomOutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            resizableImageControl1.zoomFactor *= 0.9f;
            resizableImageControl1.Invalidate();
        }

        private void zoomResetToolStripMenuItem_Click(object sender, EventArgs e)
        {
            resizableImageControl1.zoomFactor = 1.0f;
            resizableImageControl1.Invalidate();
        }

        private void morePenColorsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            colorDialog1.Color = resizableImageControl1.PenColor;

            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                resizableImageControl1.PenColor = colorDialog1.Color;
            }
        }

        private void toolStripLabel6_Click(object sender, EventArgs e)
        {

        }

        private void toolStrip3_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void buttonLine_Click(object sender, EventArgs e)
        {
            resizableImageControl1.isLine = true;
            resizableImageControl1.CanvasUnchanged = resizableImageControl1.Canvas;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            resizableImageControl1.isLine = false;
            resizableImageControl1.isSelecting = false;
           
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using (AboutForm aboutForm = new AboutForm())
            {
                aboutForm.ShowDialog();
            }
        }

        private void buttonSelect_Click(object sender, EventArgs e)
        {
            resizableImageControl1.isSelecting = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            resizableImageControl1.normalLine = true;
        }

        private void toolStripLabel3_Click(object sender, EventArgs e)
        {

        }

        private void toolStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (resizableImageControl1.CursorLocator)
                resizableImageControl1.CursorLocator = false;
            else
                resizableImageControl1.CursorLocator = true;
        }
    }
}
