﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class FormNewImage : Form
    {
        public int ImageWidth
        {
            get { return (int)numericUpDown1.Value; }
        }

        public int ImageHeight
        {
            get { return (int)numericUpDown2.Value; }
        }

        public Color SelectedColor
        {
            get { return buttonColor.BackColor; }
        }
        public FormNewImage()
        {
            InitializeComponent();
            numericUpDown1.Value = 800;
            numericUpDown2.Value = 600;
            buttonColor.BackColor = Color.White;
        }

        private void buttonColor_Click(object sender, EventArgs e)
        {
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                buttonColor.BackColor = colorDialog1.Color;
            }
        }

        private void FormNewImage_Load(object sender, EventArgs e)
        {

        }

        private void buttonColor_Click_1(object sender, EventArgs e)
        {
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                buttonColor.BackColor = colorDialog1.Color;
            }
        }

        private void buttonOK_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.OK;
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
        }
    }
}
