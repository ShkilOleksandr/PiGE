﻿using System.Drawing.Imaging;
using System.Drawing;
using System.Runtime.InteropServices;
using System;
//https://stackoverflow.com/questions/24701703/c-sharp-faster-alternatives-to-setpixel-and-getpixel-for-bitmaps-for-windows-f/34801225#34801225
public class DirectBitmap : IDisposable
{
    public Bitmap Bitmap { get;  set; }
    public Int32[] Bits { get; private set; }
    public bool Disposed { get; private set; }
    public int Height { get; private set; }
    public int Width { get; private set; }

    protected GCHandle BitsHandle { get; private set; }

    public DirectBitmap(int width, int height)
    {
        Width = width;
        Height = height;
        Bits = new Int32[width * height];
        BitsHandle = GCHandle.Alloc(Bits, GCHandleType.Pinned);
        Bitmap = new Bitmap(width, height, width * 4, PixelFormat.Format32bppPArgb, BitsHandle.AddrOfPinnedObject());
    }

    public void SetPixel(int x, int y, Color colour)
    {
        int index = x + (y * Width);
        int col = colour.ToArgb();

        Bits[index] = col;
    }

    public Color GetPixel(int x, int y)
    {
        int index = x + (y * Width);
        int col = Bits[index];
        Color result = Color.FromArgb(col);

        return result;
    }

    public void Dispose()
    {
        if (Disposed) return;
        Disposed = true;
        Bitmap.Dispose();
        BitsHandle.Free();
    }

    public void InvertColors()
    {
        for (int i = 0; i < Bits.Length; i++)
        {
            int color = Bits[i];
            // Extract the individual color components from the ARGB color
            int alpha = (color >> 24) & 0xFF;
            int red = (color >> 16) & 0xFF;
            int green = (color >> 8) & 0xFF;
            int blue = color & 0xFF;

            // Invert each color component
            red = 255 - red;
            green = 255 - green;
            blue = 255 - blue;

            // Reassemble the color and store it back in the array
            Bits[i] = (alpha << 24) | (red << 16) | (green << 8) | blue;
        }
    }
}