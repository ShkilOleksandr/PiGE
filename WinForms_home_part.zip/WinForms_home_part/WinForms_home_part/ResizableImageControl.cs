﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;

namespace WinForms_home_part
{
    public class ResizableImageControl : Control
    {
        public DirectBitmap Canvas;
        public DirectBitmap CanvasUnchanged;
        private bool isDrawing = false;
        private Point lastPoint = Point.Empty;
        public Color CanvasColor;
        public bool isLine { get; set; }
        private Point firstLinePoint = Point.Empty;
        public Color PenColor { get; set; }
        public DirectBitmap CanvasImage;
        public float zoomFactor = 1.0f;
        public bool isSelecting = false;
        public Point selectionPoint1 = Point.Empty;
        private Rectangle selectionRect = Rectangle.Empty;
        public Point basicLine = Point.Empty;
        public bool normalLine = false;
        public ToolStripLabel MouseCoords;
        public ToolStripLabel SelectionCoords;
        public bool CursorLocator = true;

        public float ZoomFactor
        {
            get => zoomFactor;
            set
            {
                zoomFactor = value;
                Invalidate();
            }
        }
        private enum ResizeMode
        {
            None,
            BottomRight,
            Bottom,
            Right
        }

        private ResizeMode currentResizeMode = ResizeMode.None;
        private readonly int hitBoxSize = 20;
        public ResizableImageControl()
        {
            this.SetStyle(ControlStyles.OptimizedDoubleBuffer |
               ControlStyles.AllPaintingInWmPaint |
               ControlStyles.UserPaint, true);
            this.UpdateStyles();
            ResizableImageControlInitialize();
            this.Size = new Size(800, 600);
            this.Location = new Point(20, 20);
            this.SetStyle(ControlStyles.Selectable, true);
            this.TabStop = true;
        }

        public void ResizableImageControl_MouseWheel(object sender, MouseEventArgs e)
        {

            if ((Control.ModifierKeys & Keys.Control) == Keys.Control)
            {
                if (e.Delta > 0)
                {
                    ZoomIn();
                }
                else if (e.Delta < 0)
                {
                    ZoomOut();
                }
            }
        }
        public void ResizableImageControlInitialize()
        {


            Canvas = new DirectBitmap(800, 600);
            CanvasImage = new DirectBitmap(800, 600);
            this.CanvasColor = Color.White;
            this.PenColor = Color.Black;
            using (Graphics g = Graphics.FromImage(Canvas.Bitmap))
            {
                g.Clear(CanvasColor); 
            }
        }
        public void LoadImage(Bitmap image)
        {
            Canvas?.Dispose();


            Canvas = new DirectBitmap(image.Width, image.Height);

       
            Rectangle rect = new Rectangle(0, 0, image.Width, image.Height);
            System.Drawing.Imaging.BitmapData bmpData =
                image.LockBits(rect, System.Drawing.Imaging.ImageLockMode.ReadOnly, image.PixelFormat);

            int bytesPerPixel = System.Drawing.Image.GetPixelFormatSize(image.PixelFormat) / 8;
            int byteCount = bmpData.Stride * image.Height;
            byte[] pixels = new byte[byteCount];
            IntPtr ptrFirstPixel = bmpData.Scan0;

            System.Runtime.InteropServices.Marshal.Copy(ptrFirstPixel, pixels, 0, pixels.Length);
            int heightInPixels = bmpData.Height;
            int widthInBytes = bmpData.Width * bytesPerPixel;

         
            for (int y = 0; y < heightInPixels; y++)
            {
                int currentLine = y * bmpData.Stride;
                for (int x = 0; x < widthInBytes; x = x + bytesPerPixel)
                {
                    int idx = currentLine + x;
                    int b = pixels[idx];
                    int g = pixels[idx + 1];
                    int r = pixels[idx + 2];
                    int a = bytesPerPixel >= 4 ? pixels[idx + 3] : 255; 
                    Color color = Color.FromArgb(a, r, g, b);
                    Canvas.SetPixel(x / bytesPerPixel, y, color);
                }
            }

            image.UnlockBits(bmpData);
            this.Size = new Size(Canvas.Width, Canvas.Height);
            this.Invalidate();
        }

        public void ZoomIn()
        {
            ZoomFactor *= 1.1f;
            UpdateControlSize();
        }

        public void ZoomOut()
        {
            ZoomFactor *= 0.9f;
            UpdateControlSize();
        }
        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            if (Canvas != null)
            {
                int zoomedWidth = (int)(Canvas.Width * zoomFactor);
                int zoomedHeight = (int)(Canvas.Height * zoomFactor);
                e.Graphics.DrawImage(Canvas.Bitmap, new Rectangle(0, 0, zoomedWidth, zoomedHeight));
            }
            if (isSelecting || selectionRect != Rectangle.Empty)
            {
                using (Pen dashPen = new Pen(Color.Gray) { DashStyle = System.Drawing.Drawing2D.DashStyle.Dash })
                {
                    e.Graphics.DrawRectangle(dashPen, selectionRect);
                }
            }
        }
        private void UpdateControlSize()
        {
            this.Width = (int)(Canvas.Width * zoomFactor);
            this.Height = (int)(Canvas.Height * zoomFactor);
        }

        public void DrawSquaresOnBitmap(Bitmap originalBitmap)
        {
            int squareSize = 10;

            using (Graphics graphics = Graphics.FromImage(originalBitmap))
            {
                using (Brush squareBrush = new SolidBrush(Color.Blue))
                {


                    graphics.FillRectangle(squareBrush, originalBitmap.Width / 2 - squareSize, originalBitmap.Height - squareSize, squareSize, squareSize);


                    graphics.FillRectangle(squareBrush, originalBitmap.Width - squareSize, originalBitmap.Height - squareSize, squareSize, squareSize);


                    graphics.FillRectangle(squareBrush, originalBitmap.Width - squareSize, originalBitmap.Height / 2, squareSize, squareSize);
                }
            }
        }
        protected override void OnMouseDown(MouseEventArgs e)
        {
            
            base.OnMouseDown(e);
            if (e.Button == MouseButtons.Left && !isDrawing)
            {
               // isSelecting = true;
                Point selectionStart = AdjustPointForZoomAndScroll(e.Location);
                selectionRect = new Rectangle(selectionStart, new Size());
            }
            this.Focus();
            Point adjustedPoint = AdjustPointForZoomAndScroll(e.Location);
            bool nearRightEdge = Math.Abs(e.X - this.Width) <= hitBoxSize;
            bool nearBottomEdge = Math.Abs(e.Y - this.Height) <= hitBoxSize;
            Selection(adjustedPoint);
            
            if (nearRightEdge && nearBottomEdge)
            {
                currentResizeMode = ResizeMode.BottomRight;
            }
            else if (nearBottomEdge)
            {
                currentResizeMode = ResizeMode.Bottom;
            }
            else if (nearRightEdge)
            {
                currentResizeMode = ResizeMode.Right;
            }
            if(isLine)
            {
                //CanvasUnchanged = Canvas;
                firstLinePoint = adjustedPoint;
            }
            if(normalLine)
            {
                if(basicLine.IsEmpty)
                    basicLine = adjustedPoint;
                else
                {
                    using (Graphics g = Graphics.FromImage(Canvas.Bitmap))
                    {

                        g.DrawLine(new Pen(PenColor, 2), basicLine, adjustedPoint);
                        
                    }
                    basicLine = Point.Empty;
                    normalLine = false;
                }
            }
            isDrawing = e.Button == MouseButtons.Left;
            lastPoint = adjustedPoint;

        }
        protected override void Dispose(bool disposing)
        {
            if (disposing && Canvas != null)
            {
                Canvas.Dispose();
            }
            base.Dispose(disposing);
        }
        private void Selection(Point p)
        {
            if (isSelecting)
            {
                if (selectionPoint1.IsEmpty)
                {
                    selectionPoint1 = p;
                }
                else
                {
                    SelectionCoords.Text = $"Selected Area: {selectionPoint1.X} px, {selectionPoint1.Y} px,  {p.X} px, {p.Y} px.";
                    selectionPoint1 = Point.Empty;
                    isSelecting = false;
                }
            }
        }
        protected override void OnMouseMove(MouseEventArgs e)
        {
            Point adjustedPoint = AdjustPointForZoomAndScroll(e.Location);
            UpdateCursorForEdgeProximity(adjustedPoint);
            if(CursorLocator)
                MouseCoords.Text = $"Painting Position: {adjustedPoint.X}, {adjustedPoint.Y} px      ";
            
            if (currentResizeMode != ResizeMode.None)
            {
                int newWidth = this.Width, newHeight = this.Height;
                switch (currentResizeMode)
                {
                    case ResizeMode.Right:
                        newWidth = Math.Max(e.X, MinimumSize.Width);
                        break;
                    case ResizeMode.Bottom:
                        newHeight = Math.Max(e.Y, MinimumSize.Height);
                        break;
                    case ResizeMode.BottomRight:
                        newWidth = Math.Max(e.X, MinimumSize.Width);
                        newHeight = Math.Max(e.Y, MinimumSize.Height);
                        break;
                }

                if (newWidth != this.Width || newHeight != this.Height)
                {
                    ResizeBitmap(newWidth, newHeight);
                    this.Width = newWidth;
                    this.Height = newHeight;
                    this.Invalidate();
                }
            }
            else if (isDrawing && lastPoint != Point.Empty)
            {
                int minX = Math.Min(lastPoint.X, adjustedPoint.X);
                int minY = Math.Min(lastPoint.Y, adjustedPoint.Y);
                int maxX = Math.Max(lastPoint.X, adjustedPoint.X);
                int maxY = Math.Max(lastPoint.Y, adjustedPoint.Y);
                int penWidth = 1;
                Rectangle invalidatedArea = new Rectangle(minX - penWidth, minY - penWidth, (maxX - minX) + (penWidth * 2), (maxY - minY) + (penWidth * 2));

                if (adjustedPoint.X >= 0 && adjustedPoint.Y >= 0 && adjustedPoint.X < Canvas.Width && adjustedPoint.Y < Canvas.Height)
                {
                    if (isLine)
                    {
                        
                        using (Graphics g = Graphics.FromImage(CanvasUnchanged.Bitmap))
                        {
                            int zoomedWidth = (int)(Canvas.Width * zoomFactor);
                            int zoomedHeight = (int)(Canvas.Height * zoomFactor);
                         
                            g.DrawLine(new Pen(PenColor, penWidth), firstLinePoint, adjustedPoint);
                            Invalidate();
                            return;
                        }

                    }
                    else
                    {


                        using (Graphics g = Graphics.FromImage(Canvas.Bitmap))
                        {

                            g.DrawLine(new Pen(PenColor, penWidth), lastPoint, adjustedPoint);

                        }
                    }
                    lastPoint = adjustedPoint;
                    invalidatedArea = new Rectangle(
                     (int)(invalidatedArea.X * zoomFactor),
                     (int)(invalidatedArea.Y * zoomFactor),
                     (int)(invalidatedArea.Width * zoomFactor),
                     (int)(invalidatedArea.Height * zoomFactor)
                        );
                   // Point previousScrollPosition = new Point(Math.Abs((this.Parent as Panel).AutoScrollPosition.X), Math.Abs((this.Parent as Panel).AutoScrollPosition.Y));

                    Invalidate(invalidatedArea);

                  


                }
            }
        }
        private void UpdateCursorForEdgeProximity(Point mouseLocation)
        {
            bool nearRightEdge = Math.Abs(mouseLocation.X - this.Width) <= hitBoxSize;
            bool nearBottomEdge = Math.Abs(mouseLocation.Y - this.Height) <= hitBoxSize;

            if (nearRightEdge && nearBottomEdge)
            {
                this.Cursor = Cursors.SizeNWSE;
            }
            else if (nearRightEdge)
            {
                this.Cursor = Cursors.SizeWE;
            }
            else if (nearBottomEdge)
            {
                this.Cursor = Cursors.SizeNS;
            }
            else
            {
                this.Cursor = Cursors.Default;
            }
        }
        private void ResizeBitmap(int newWidth, int newHeight)
        {
            DirectBitmap newCanvas = new DirectBitmap(newWidth, newHeight);
            using (Graphics g = Graphics.FromImage(newCanvas.Bitmap))
            {
                g.Clear(this.CanvasColor);
                g.DrawImage(this.Canvas.Bitmap, 0, 0, this.Canvas.Width, this.Canvas.Height);
            }
            this.Canvas.Dispose();
            this.Canvas = newCanvas;
        }
        private Point AdjustPointForZoomAndScroll(Point originalPoint)
        {
            Point scrollOffset = Point.Empty;
            return new Point(
                (int)((originalPoint.X) / zoomFactor),
                (int)((originalPoint.Y) / zoomFactor)
            );
        }
        protected override void OnMouseUp(MouseEventArgs e)
        {
            base.OnMouseUp(e);
            if (isSelecting)
            {
                isSelecting = false;
                this.Invalidate(); 
            }
            currentResizeMode = ResizeMode.None;
           
            if (isDrawing)
            {
                isDrawing = false;
            }
        }
    }
}