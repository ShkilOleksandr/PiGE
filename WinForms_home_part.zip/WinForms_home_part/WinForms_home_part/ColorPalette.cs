﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinForms_home_part
{
    public class ColorPaletteControl : Control
    {
        // Event triggered when a color is selected
        public event EventHandler<Color> ColorSelected;

        private Color[] colors = new Color[] {
            Color.Red, Color.Green, Color.Blue, // Add more colors as needed
        };
        private int colorSize = 20; // Size of each color box

        public ColorPaletteControl()
        {
            this.DoubleBuffered = true; // For smoother rendering
            this.ResizeRedraw = true; // Redraw when control is resized
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);

            Graphics g = e.Graphics;
            for (int i = 0; i < colors.Length; i++)
            {
                int row = i / GetColumnsCount();
                int col = i % GetColumnsCount();

                using (Brush brush = new SolidBrush(colors[i]))
                {
                    g.FillRectangle(brush, col * colorSize, row * colorSize, colorSize, colorSize);
                }

                g.DrawRectangle(Pens.Black, col * colorSize, row * colorSize, colorSize, colorSize);
            }
        }

        private int GetColumnsCount()
        {
            return Width / colorSize;
        }

        protected override void OnMouseDown(MouseEventArgs e)
        {
            base.OnMouseDown(e);

            int col = e.X / colorSize;
            int row = e.Y / colorSize;
            int index = row * GetColumnsCount() + col;

            if (index >= 0 && index < colors.Length)
            {
                ColorSelected?.Invoke(this, colors[index]);
            }
        }

        protected override void OnSizeChanged(EventArgs e)
        {
            base.OnSizeChanged(e);
            Invalidate(); // Ensure control is repainted when resized
        }
    }
}
