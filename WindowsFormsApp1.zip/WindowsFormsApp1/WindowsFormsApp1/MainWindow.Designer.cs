﻿namespace WindowsFormsApp1
{
    partial class MainWindow
    {
        
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.newBlueprintToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.Canvas = new System.Windows.Forms.PictureBox();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.buttonTable = new System.Windows.Forms.Button();
            this.buttonCoffeeTable = new System.Windows.Forms.Button();
            this.buttonDoubleBed = new System.Windows.Forms.Button();
            this.buttonSofa = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.furnitureListBox = new System.Windows.Forms.ListBox();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Canvas)).BeginInit();
            this.tableLayoutPanel1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(772, 28);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newBlueprintToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(46, 24);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // newBlueprintToolStripMenuItem
            // 
            this.newBlueprintToolStripMenuItem.Name = "newBlueprintToolStripMenuItem";
            this.newBlueprintToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F2;
            this.newBlueprintToolStripMenuItem.Size = new System.Drawing.Size(210, 26);
            this.newBlueprintToolStripMenuItem.Text = "New Blueprint";
            this.newBlueprintToolStripMenuItem.Click += new System.EventHandler(this.newBlueprintToolStripMenuItem_Click);
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 28);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.Canvas);
            this.splitContainer1.Panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.splitContainer1_Panel1_Paint);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.tableLayoutPanel1);
            this.splitContainer1.Size = new System.Drawing.Size(772, 483);
            this.splitContainer1.SplitterDistance = 455;
            this.splitContainer1.TabIndex = 1;
            // 
            // Canvas
            // 
            this.Canvas.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Canvas.Location = new System.Drawing.Point(0, 0);
            this.Canvas.Name = "Canvas";
            this.Canvas.Size = new System.Drawing.Size(455, 483);
            this.Canvas.TabIndex = 0;
            this.Canvas.TabStop = false;
            this.Canvas.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Canvas_MouseDown);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.groupBox1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.groupBox2, 0, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(313, 483);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.flowLayoutPanel1);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Location = new System.Drawing.Point(3, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(307, 235);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Add furniture";
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Controls.Add(this.buttonTable);
            this.flowLayoutPanel1.Controls.Add(this.buttonCoffeeTable);
            this.flowLayoutPanel1.Controls.Add(this.buttonDoubleBed);
            this.flowLayoutPanel1.Controls.Add(this.buttonSofa);
            this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(3, 18);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(301, 214);
            this.flowLayoutPanel1.TabIndex = 0;
            // 
            // buttonTable
            // 
            this.buttonTable.BackColor = System.Drawing.SystemColors.Window;
            this.buttonTable.BackgroundImage = global::WindowsFormsApp1.Properties.Resources.table;
            this.buttonTable.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonTable.Location = new System.Drawing.Point(3, 3);
            this.buttonTable.Name = "buttonTable";
            this.buttonTable.Size = new System.Drawing.Size(75, 75);
            this.buttonTable.TabIndex = 0;
            this.buttonTable.Tag = "Table";
            this.buttonTable.UseVisualStyleBackColor = false;
            this.buttonTable.Click += new System.EventHandler(this.buttonTable_Click);
            // 
            // buttonCoffeeTable
            // 
            this.buttonCoffeeTable.BackColor = System.Drawing.SystemColors.Window;
            this.buttonCoffeeTable.BackgroundImage = global::WindowsFormsApp1.Properties.Resources.coffee_table;
            this.buttonCoffeeTable.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonCoffeeTable.Location = new System.Drawing.Point(84, 3);
            this.buttonCoffeeTable.Name = "buttonCoffeeTable";
            this.buttonCoffeeTable.Size = new System.Drawing.Size(75, 75);
            this.buttonCoffeeTable.TabIndex = 1;
            this.buttonCoffeeTable.Tag = "Coffee Table";
            this.buttonCoffeeTable.UseVisualStyleBackColor = false;
            this.buttonCoffeeTable.Click += new System.EventHandler(this.buttonCoffeeTable_Click);
            // 
            // buttonDoubleBed
            // 
            this.buttonDoubleBed.BackColor = System.Drawing.Color.White;
            this.buttonDoubleBed.BackgroundImage = global::WindowsFormsApp1.Properties.Resources.double_bed;
            this.buttonDoubleBed.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonDoubleBed.Location = new System.Drawing.Point(165, 3);
            this.buttonDoubleBed.Name = "buttonDoubleBed";
            this.buttonDoubleBed.Size = new System.Drawing.Size(75, 75);
            this.buttonDoubleBed.TabIndex = 2;
            this.buttonDoubleBed.Tag = "Double Bed";
            this.buttonDoubleBed.UseVisualStyleBackColor = false;
            this.buttonDoubleBed.Click += new System.EventHandler(this.buttonDoubleBed_Click);
            // 
            // buttonSofa
            // 
            this.buttonSofa.BackColor = System.Drawing.Color.White;
            this.buttonSofa.BackgroundImage = global::WindowsFormsApp1.Properties.Resources.sofa;
            this.buttonSofa.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonSofa.Location = new System.Drawing.Point(3, 84);
            this.buttonSofa.Name = "buttonSofa";
            this.buttonSofa.Size = new System.Drawing.Size(75, 75);
            this.buttonSofa.TabIndex = 3;
            this.buttonSofa.Tag = "Sofa";
            this.buttonSofa.UseVisualStyleBackColor = false;
            this.buttonSofa.Click += new System.EventHandler(this.buttonSofa_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.furnitureListBox);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox2.Location = new System.Drawing.Point(3, 244);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(307, 236);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Created";
            // 
            // furnitureListBox
            // 
            this.furnitureListBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.furnitureListBox.FormattingEnabled = true;
            this.furnitureListBox.ItemHeight = 16;
            this.furnitureListBox.Location = new System.Drawing.Point(3, 18);
            this.furnitureListBox.Name = "furnitureListBox";
            this.furnitureListBox.Size = new System.Drawing.Size(301, 215);
            this.furnitureListBox.TabIndex = 0;
            // 
            // MainWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(772, 511);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.MinimumSize = new System.Drawing.Size(400, 300);
            this.Name = "MainWindow";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Room designer";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Canvas)).EndInit();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.flowLayoutPanel1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem newBlueprintToolStripMenuItem;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.PictureBox Canvas;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Button buttonTable;
        private System.Windows.Forms.Button buttonCoffeeTable;
        private System.Windows.Forms.Button buttonDoubleBed;
        private System.Windows.Forms.Button buttonSofa;
        private System.Windows.Forms.ListBox furnitureListBox;
    }
}

